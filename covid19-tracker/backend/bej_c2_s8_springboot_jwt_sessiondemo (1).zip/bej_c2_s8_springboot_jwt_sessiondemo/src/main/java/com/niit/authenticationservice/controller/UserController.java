package com.niit.authenticationservice.controller;

import com.niit.authenticationservice.service.UserService;
import com.niit.authenticationservice.domain.User;
import com.niit.authenticationservice.domain.Watchlist;
import com.niit.authenticationservice.exception.UserNotFoundException;
import com.niit.authenticationservice.filter.JwtFilter;
import com.niit.authenticationservice.repository.UserRepository;
import com.niit.authenticationservice.service.SecurityTokenGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import javax.servlet.http.HttpServletRequest;

import java.net.http.HttpHeaders;
import java.security.PublicKey;
import java.util.List;
import java.util.Map;
import io.jsonwebtoken.Claims;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
public class UserController {

	private ResponseEntity responseEntity;
	@Autowired
	private UserService userService;
	@Autowired
	private RestTemplate restTemplate;

	private SecurityTokenGenerator securityTokenGenerator;

	private String BASE_URL = "http://localhost:8080/watchlist/";

	@Autowired
	public UserRepository userRepository;

	public UserController(UserService userService, SecurityTokenGenerator securityTokenGenerator) {
		this.userService = userService;
		this.securityTokenGenerator = securityTokenGenerator;
	}

	// Should only give username and password
	@PostMapping("/login")
	public ResponseEntity loginUser(@RequestBody User user) throws UserNotFoundException {

		Map<String, String> map = null;
		try {
			User userObj = userService.findByEmailAndPassword(user.getEmail(), user.getPassword());
			if (userObj.getEmail().equals(user.getEmail())) {
				map = securityTokenGenerator.generateToken(userObj);
			}
			responseEntity = new ResponseEntity(map, HttpStatus.OK);
		} catch (UserNotFoundException e) {
			throw new UserNotFoundException();
		} catch (Exception e) {
			responseEntity = new ResponseEntity("Try after sometime!!!", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return responseEntity;
	}

	// first step - register the user
	@PostMapping("/register")
	public ResponseEntity saveUser(@RequestBody User user) {

		User createdUser = userService.saveUser(user);
		return responseEntity = new ResponseEntity("User Created", HttpStatus.CREATED);
	}

	@GetMapping("/api/v1/userservice/users")
	public ResponseEntity getAllUsers(HttpServletRequest request) {
		System.out.println("claims:------------");
		System.out.println(request.getAttribute("claims"));
		List<User> list = userService.getAllUsers();
		responseEntity = new ResponseEntity(list, HttpStatus.OK);
		return responseEntity;

	}

	@GetMapping("/api/v1/self")
	public ResponseEntity getSelf(HttpServletRequest request) {
		System.out.println("claims:------------");
		System.out.println(Integer.valueOf(request.getAttribute("userId").toString()));
		User list = userService.findByUserId(Integer.valueOf(request.getAttribute("userId").toString()));
		responseEntity = new ResponseEntity(list, HttpStatus.OK);
		return responseEntity;

	}

	// to edit the details
	@PostMapping("/api/v1/edit")
	public ResponseEntity editUser(@RequestBody User user) {
		User updatedUser = userService.editUser(user);
		return responseEntity = new ResponseEntity("User Updated", HttpStatus.OK);

	}

	// to update password

	@PostMapping("/api/v1/changepassword")
	public ResponseEntity changePassword(HttpServletRequest request, @RequestBody User user) {
		try {
			User userObj = userRepository.findByUserId(Integer.parseInt(request.getAttribute("userId").toString()));
			System.out.println("usereIs");
			System.out.println(Integer.parseInt(request.getAttribute("userId").toString()));
//		 if(userObj.getUserId()==(user.getUserId())) {
			user.setUserId(Integer.parseInt(request.getAttribute("userId").toString()));
			User updatedUser = userService.changePassword(user);
			return responseEntity = new ResponseEntity(updatedUser, HttpStatus.OK);
//		 }
//		 else {
//			 return responseEntity = new ResponseEntity("userId not matched" , HttpStatus.OK);
//		 }

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return responseEntity = new ResponseEntity("Something went Wrong", HttpStatus.INTERNAL_SERVER_ERROR);

	}

	// for watch list
	@GetMapping("/api/v1/watchlist")
	public ResponseEntity getWatchlist(HttpServletRequest request) {
		System.out.println(Integer.valueOf(request.getAttribute("userId").toString()));
		List resp = this.restTemplate.getForObject(BASE_URL + request.getAttribute("userId").toString(), List.class);
		responseEntity = new ResponseEntity(resp, HttpStatus.OK);
		return responseEntity;

	}

	/**
	 * @implNote this api will add a watchlist
	 */

	@PostMapping("/api/v1/watchlist")
	public ResponseEntity addWatchList(HttpServletRequest request, @RequestBody Watchlist watch) {
//	  HttpHeaders headers=new HttpHeaders();
		Watchlist dataWatchlist = new Watchlist(Integer.valueOf(request.getAttribute("userId").toString()),
				watch.getCountry(), watch.getDetails());

		MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
		headers.add("Content-Type", "application/json");

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());

		HttpEntity<Watchlist> data = new HttpEntity<Watchlist>(dataWatchlist, headers);

		List<Watchlist> resp = restTemplate.postForObject(BASE_URL, data, List.class);
//	  Watchlist resp = this.restTemplate.postForObject(BASE_URL, dataWatchlist, Watchlist.class);
		responseEntity = new ResponseEntity(resp, HttpStatus.OK);
		return responseEntity;
	}

	@DeleteMapping("/api/v1/watchlist/{id}")
	public ResponseEntity deleteWatchlist(@PathVariable("id") String docId) {
		restTemplate.delete(BASE_URL + docId);
		responseEntity = new ResponseEntity("Deleted!!", HttpStatus.OK);
		return responseEntity;
	}

}
