package com.niit.authenticationservice.service;


import com.niit.authenticationservice.domain.User;
import com.niit.authenticationservice.exception.UserNotFoundException;

import java.util.List;


public interface UserService {

  public User saveUser(User user);
  public User findByEmailAndPassword(String email , String password) throws UserNotFoundException;
  List<User> getAllUsers();
public User editUser(User user);
public User changePassword(User user);
public User findByUserId(Integer userId);




//  boolean validateUser(String username, String password) throws UserNotFoundException;

}
